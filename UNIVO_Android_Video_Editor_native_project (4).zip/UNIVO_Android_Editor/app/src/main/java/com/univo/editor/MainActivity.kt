package com.univo.editor

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ProgressHolder
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var status: TextView
    private lateinit var startLabel: TextView
    private lateinit var endLabel: TextView
    private lateinit var startSeek: SeekBar
    private lateinit var endSeek: SeekBar
    private lateinit var exportButton: Button
    private var videoUri: Uri? = null
    private var durationMs = 0L
    private var startMs = 0L
    private var endMs = 0L
    private var transformer: Transformer? = null
    private var outputFile: File? = null
    private var savedVideoUri: Uri? = null
    private val handler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && durationMs == 0L) {
                    durationMs = player.duration.coerceAtLeast(0L)
                    endMs = durationMs
                    updateTrimLabels()
                }
            }
        })
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            setBackgroundColor(0xFF0B1018.toInt())
        }
        val scroll = android.widget.ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply { text = "UNIVO VIDEO EDITOR"; textSize = 22f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(12)) }
        root.addView(title)
        val sub = TextView(this).apply { text = "Android prototype · Select, preview, trim and export"; textSize = 14f; setTextColor(0xFFB4C2D6.toInt()); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(12)) }
        root.addView(sub)
        val pick = makeButton("Choose video from phone") { pickVideo.launch("video/*") }
        root.addView(pick)
        playerView = PlayerView(this).apply { useController = true; setBackgroundColor(0xFF000000.toInt()) }
        root.addView(playerView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220)).apply { topMargin = dp(10) })

        startLabel = makeLabel("Trim start: 0.0 s")
        root.addView(startLabel)
        startSeek = SeekBar(this).apply { max = 1000; isEnabled = false }
        root.addView(startSeek)
        endLabel = makeLabel("Trim end: 0.0 s")
        root.addView(endLabel)
        endSeek = SeekBar(this).apply { max = 1000; isEnabled = false }
        root.addView(endSeek)
        startSeek.setOnSeekBarChangeListener(seekListener(true))
        endSeek.setOnSeekBarChangeListener(seekListener(false))

        val full = makeButton("Reset trim to full video") { startMs = 0; endMs = durationMs; updateTrimControls() }
        root.addView(full)
        exportButton = makeButton("Export trimmed MP4") { startExport() }.apply { isEnabled = false }
        root.addView(exportButton)
        status = makeLabel("Choose a video to begin.")
        status.setTextColor(0xFF9DE3B1.toInt())
        status.setPadding(0, dp(12), 0, dp(8))
        root.addView(status)
        root.addView(makeButton("Share last export") { shareExport() })
        root.addView(makeLabel("Stage 1 Android build: video picker, preview, trim range, MP4 export. More tools will be added in later versions."))
    }

    private fun seekListener(isStart: Boolean) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
            if (!fromUser || durationMs <= 0) return
            val value = durationMs * progress / 1000
            if (isStart) startMs = value.coerceAtMost((endMs - 500).coerceAtLeast(0)) else endMs = value.coerceAtLeast(startMs + 500).coerceAtMost(durationMs)
            updateTrimLabels()
        }
        override fun onStartTrackingTouch(seekBar: SeekBar) {}
        override fun onStopTrackingTouch(seekBar: SeekBar) {}
    }

    private fun loadVideo(uri: Uri) {
        videoUri = uri
        durationMs = 0
        startMs = 0
        endMs = 0
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.playWhenReady = false
        startSeek.isEnabled = true
        endSeek.isEnabled = true
        exportButton.isEnabled = true
        status.text = "Video loaded. Wait for preview duration, then set trim points."
    }

    private fun updateTrimControls() {
        startSeek.progress = if (durationMs > 0) (startMs * 1000 / durationMs).toInt() else 0
        endSeek.progress = if (durationMs > 0) (endMs * 1000 / durationMs).toInt() else 1000
        updateTrimLabels()
    }

    private fun updateTrimLabels() {
        startLabel.text = "Trim start: ${startMs / 1000f} s"
        endLabel.text = "Trim end: ${endMs / 1000f} s"
        if (durationMs > 0) updateTrimControlsNoRecursion()
    }

    private fun updateTrimControlsNoRecursion() {
        startSeek.progress = (startMs * 1000 / durationMs).toInt().coerceIn(0, 1000)
        endSeek.progress = (endMs * 1000 / durationMs).toInt().coerceIn(0, 1000)
    }

    private fun startExport() {
        val uri = videoUri ?: return toast("Pick a video first")
        if (durationMs <= 0L) return toast("Video is still loading")
        if (endMs <= startMs || endMs - startMs < 500) return toast("Choose a trim range of at least 0.5 seconds")
        exportButton.isEnabled = false
        status.text = "Preparing MP4 export…"
        val file = File(cacheDir, "univo_export_${System.currentTimeMillis()}.mp4")
        outputFile = file
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs).setEndPositionMs(endMs).build()
        ).build()
        val edited = EditedMediaItem.Builder(item).build()
        transformer = Transformer.Builder(this).setVideoMimeType("video/avc").setAudioMimeType("audio/mp4a-latm")
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    exportButton.isEnabled = true
                    status.text = "Export complete. Saving to Movies/UNIVO…"
                    saveToGallery(file)
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    exportButton.isEnabled = true
                    status.text = "Export failed: ${exportException.message ?: "Unknown error"}"
                    file.delete()
                }
            }).build()
        try {
            transformer?.start(edited, file.absolutePath)
            pollProgress()
        } catch (e: Exception) {
            exportButton.isEnabled = true
            status.text = "Could not start export: ${e.message}"
        }
    }

    private fun pollProgress() {
        val t = transformer ?: return
        val state = t.getProgress(progressHolder)
        if (state == Transformer.PROGRESS_STATE_AVAILABLE) status.text = "Exporting: ${progressHolder.progress}%"
        if (!exportButton.isEnabled) handler.postDelayed({ pollProgress() }, 500)
    }

    private fun saveToGallery(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "UNIVO_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/UNIVO")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Gallery destination unavailable")
            contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(file).use { input -> input.copyTo(out) } }
            savedVideoUri = uri
            file.delete()
            status.text = "Saved to Gallery → Movies/UNIVO"
            toast("Export saved to Movies/UNIVO")
        } catch (e: Exception) {
            status.text = "Export finished, but gallery save failed: ${e.message}. File remains in app cache."
        }
    }

    private fun shareExport() {
        val uri = savedVideoUri
        if (uri == null) { toast("Export a video first"); return }
        val share = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(android.content.Intent.createChooser(share, "Share video")) } catch (e: Exception) { toast("Share failed: ${e.message}") }
    }

    private fun makeButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
        setTextColor(0xFFFFFFFF.toInt())
    }
    private fun makeLabel(text: String): TextView = TextView(this).apply { this.text = text; textSize = 14f; setTextColor(0xFFE6EEFA.toInt()); setPadding(0, dp(7), 0, dp(7)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
