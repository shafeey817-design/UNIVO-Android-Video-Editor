# UNIVO Android Video Editor — first native Android prototype

Package: `com.univo.editor` (separate prototype app; not yet merged into UNIVO social app)

## Implemented in this first Android build
- Android video picker (user-selected file; no broad storage permission)
- Video preview using Media3 ExoPlayer
- Trim start/end markers
- Export trimmed segment to H.264 MP4 using Media3 Transformer
- Save export to Gallery/Movies/UNIVO using MediaStore
- Share last successful export

## Not implemented yet
- Timeline with multiple clips, split/merge, transitions
- Text overlays, filters, stickers, music mixing
- Project files and undo/redo
- Export presets, progress refinements, app-wide localization

## Build APK in cloud
The `.github/workflows/build-apk.yml` workflow is included. Upload this project folder's files to a GitHub repository (root must contain `settings.gradle`, `build.gradle`, `app/`, and `.github/`). In the repository, open Actions → **Build UNIVO Android APK** → Run workflow. When it completes, open the workflow run and download the artifact named `UNIVO-Video-Editor-debug-APK`. Extract the artifact ZIP to get `app-debug.apk`, then install it on Android. You may need to allow installation from the browser/files app when Android asks.

## Notes
- This source has been prepared but not compiled in this environment. Cloud build is the next verification step. Android Media3 dependencies require internet during build.
- The first prototype uses a native Android Activity UI. This is not yet the final polished app and does not contain the previous browser prototype's 100-stage feature set.
